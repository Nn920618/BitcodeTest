//
//  AppDelegate.h
//  BitCodeTest
//
//  Created by Nn on 16/8/10.
//  Copyright © 2016年 Nn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

