//
//  ViewController.m
//  BitCodeTest
//
//  Created by Nn on 16/8/10.
//  Copyright © 2016年 Nn. All rights reserved.
//

#import "ViewController.h"
#import "TXYUploadManager.h"

@interface ViewController ()
@property (nonatomic) TXYUploadManager *txyUploadManager;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
    _txyUploadManager = [[TXYUploadManager alloc] initWithCloudType:TXYCloudTypeForVideo
                                                      persistenceId:nil
                                                              appId:@"VVVVVVV"];
    
}
- (void)test
{
    TXYVideoFileInfo *fileInfo = [[TXYVideoFileInfo alloc] init];
    fileInfo.title = @"FileName";
    fileInfo.desc = @"对庄视频";
    TXYVideoUploadTask *uploadTask = [[TXYVideoUploadTask alloc] initWithPath:@""
                                                                         sign:@""
                                                                       bucket:@""
                                                                     fileName:@"AAAAAA"
                                                              customAttribute:nil
                                                              uploadDirectory:@"BBBBB"
                                                                videoFileInfo:fileInfo
                                                                   msgContext:nil
                                                                   insertOnly:YES];
    __weak typeof(self) weakSelf = self;
    BOOL start = [self.txyUploadManager upload:uploadTask
                                      complete:^(TXYTaskRsp *resp, NSDictionary *context)
                  {
                      __strong typeof(weakSelf) strongSelf = weakSelf;
                      
                      NSLog(@"%@  %@", strongSelf, context);
                  } progress:^(int64_t totalSize, int64_t sendSize, NSDictionary *context)
                  {
//                      __strong typeof(weakSelf) strongSelf = weakSelf;
//                      float progress = (float)sendSize / (float)totalSize;
                  } stateChange:^(TXYUploadTaskState state, NSDictionary *context)
                  {
                      
                  }];
    if (start == NO)
    {
        NSLog(@"上传任务创建失败");
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
